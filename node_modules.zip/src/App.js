

import './App.css';
import React from 'react';
import Login from './Components/login';
// import signin from './Components/signin'

function App() {
  return (
    <div >
      <Login/>
      
    </div>
  );
}

export default App;
